<?php

require_once 'src/Auth.php';
require_once 'src/Challenges.php';
require_once 'src/Items.php';
require_once 'src/Leaderboard.php';
require_once 'src/News.php';
require_once 'src/Patchnotes.php';
require_once 'src/PVE.php';
require_once 'src/Status.php';
require_once 'src/User.php';
require_once 'src/Weapons.php';

require_once 'Client.php';

?>
